exports.constant = {
    validation_error : 400,
    UNAUTHORISED :401,
    FORBIDDEN :403,
    Not_found : 404,
    SERVER_ERROR:500

}