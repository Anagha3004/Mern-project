const mongoose = require("mongoose");

const contactschema = mongoose.Schema({
    // user_id:{
    //     type:mongoose.Schema.Types.ObjectId,
    //     required:true,
    //     ref:"user"
    // },
    name:{
        type:String,
        required: [true, "please enter"]
    },
    email:{
        type:String,
        required: [true, "please enter"]
    },
    phone:{
        type:String,
        required: [true, "please enter"]
    },
})


module.exports = mongoose.model("connect", contactschema)