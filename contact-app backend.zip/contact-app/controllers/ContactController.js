// get all contact

const asynchandler = require("express-async-handler");
const contact = require("../model/ContactModels");


const getcontact = asynchandler(async (req, res) => {
    try {
        // Fetch all contacts from the database
        const contacts = await contact.find({});
       
        
        // Return the contacts as a JSON response
        res.status(200).json(contacts); 
    } catch (err) {
        // Return an error if something goes wrong
        res.status(500).json({ message: "Server Error", error: err.message });
    }
});

// create contact
const created = asynchandler(async(req,res)=>{
    console.log(req.body);
    const {name,email,phone}= req.body;
    if(!name || !email || !phone){
        res.status(400);
        throw new Error(" all fileds are maditory")
    }
    const newcontact =  await contact.create({
        name,
        email,
        phone,
        // user_id:req.user.id
    });
    res.status(201).json(newcontact)
})

const deletecontact = asynchandler(async (req, res) => {
    const contactss = await contact.findById(req.params.id);
    
    if (!contactss) {
        res.status(404);
        throw new Error("No contact found");
    }
    if(contactss.user_id.toString() !== req.user.id){
        res.status(403)
        throw new Error("user dont have permission")
    }
    await contactss.deleteOne({_id: req.params.id})
    res.status(200).json(contactss);  // Respond with the deleted contact's information
});


const updatecontact = asynchandler(async(req,res)=>{
    const contactF = await contact.findById(req.params.id);
    if(!contactF){
        res.status(404);
        throw new Error("not found");
    }
    if(contactF.user_id.toString() !== req.user.id){
        res.status(403)
        throw new Error("user dont have permission")
    }

    const updatecontat = await contact.findByIdAndUpdate(
        req.params.id,
        req.body,
        {new :true}
    )
    res.status(200).json(updatecontat)
})

const getcontc = asynchandler(async(req,res)=>{
    const contactFind = await contact.findById(req.params.id)
    if(!contactFind){
        res.status(404);
        throw new Error("not found");
        
    }
    res.status(200).json(contactFind)
})


module.exports ={getcontact,deletecontact,created,updatecontact,getcontc}