// register user

const bcrypt = require("bcrypt")
const asynchandler = require("express-async-handler");
const newUserRegister = require("../model/UserModel.js");
const validateToken = require('../middleware/ValidationToken')
const jwt = require("jsonwebtoken")

const registerUser = asynchandler (async(req,res)=>{
    const {username,email,password} = req.body;
    if(!username || !email || !password){
        res.status(400)
        throw new Error("all fields are manditory")
    }
    const Useravailable = await newUserRegister.findOne({email})
    if(Useravailable){
        res.status(400)
            throw new Error("user with this email already exits")
        
    }

    // hash password 

    const hashpassword = await bcrypt.hash(password, 10)
    console.log("hashpass",hashpassword)

    const createUser = await newUserRegister.create({
        username,
        email,
        password: hashpassword

    });
    console.log("user created", {createUser})
    if(createUser){
        res.status(200).json({id:  createUser.id, email: createUser.email})

    }else{
        res.status(400)
        throw new Error("creating user failed")
    }



   
})



const UserLogin = asynchandler(async(req,res)=>{
    const {email, password} = req.body;
    if(!email || !password){
        res.status(400)
        throw new Error("all fields are manditory")
    }
    const usercheck = await newUserRegister.findOne({email})
    if(usercheck && (await bcrypt.compare(password,usercheck.password))){
        const accesstoken = jwt.sign({
            usercheck:{
            username: usercheck.username,
            email: usercheck.email,
            id: usercheck.id
            }
            
        },process.env.SECREAT_WEB_TOKEN,
        {expiresIn : "15m"});
        res.status(200).json({accesstoken})
    }

    res.status(400).json({ message: "Invalid credentials" }); 
})


const currentUser = asynchandler(async (req, res) => {
   
    res.status(200).json(req.user); // Respond with the user object
});


module.exports = {registerUser,UserLogin,currentUser}