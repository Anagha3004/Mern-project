const asynchandler = require("express-async-handler");
const jwt = require("jsonwebtoken")


const validateToken = asynchandler(async(req,res,next)=>{
    let token;
    let authheader = req.headers.Authorization || req.headers.authorization

    if(authheader && authheader.startsWith("Bearer")){
        token = authheader.split(" ")[1]
        jwt.verify(token, process.env.SECREAT_WEB_TOKEN, (err,decoded)=>{
            if(err){
                console.log(err)
                res.status(401)
            throw new Error("user is not authorized");
            }else{
             

        req.user = decoded.usercheck;
       
        console.log(decoded)
        next();
        }  
     });
     if(!token){
        res.status(404)
        throw new Error("user is not authorised or no token")
     }

    } 

});


module.exports = validateToken;






