const { constant } = require("../constants.js");

const errorHandler = (err, req, res, next) => {
    const statuscode = res.statuscode ? res.statuscode : 500;

    if (res.headersSent) {
        return next(err);  // Pass the error to the default error handler if headers are already sent
    }

    switch (statuscode) {
        case constant.validation_error:
            res.json({ title: "Validation Error", message: err.message, stackTrace: err.stack });
            break;

        case constant.UNAUTHORISED:
            res.json({ title: "Unauthorised", message: err.message, stackTrace: err.stack });
            break;

        case constant.FORBIDDEN:
            res.json({ title: "Forbidden", message: err.message, stackTrace: err.stack });
            break;

        case constant.Not_found:
            res.json({ title: "Not Found", message: err.message, stackTrace: err.stack });
            break;

        case constant.SERVER_ERROR:
            res.json({ title: "Server Error", message: err.message, stackTrace: err.stack });
            break;

        default:
            console.log("No error");
            break;
    }
};

module.exports = errorHandler;

    
