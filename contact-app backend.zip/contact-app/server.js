const express = require("express");
const errorHandler = require("./middleware/errorHandler");
const connectionDb = require("./config/dbConnection");
const dotenv = require("dotenv").config();
const cors = require('cors');


const app= express();
app.use(cors());


connectionDb();
 

app.use(express.json());

app.use("/api/con", require("./routes/ContactRoutes"));
app.use("/api/user", require("./routes/UserRoutes"))

app.use(errorHandler)

const port = 5000
app.listen(port, ()=>{
    console.log(`server running in port ${port}`);
})