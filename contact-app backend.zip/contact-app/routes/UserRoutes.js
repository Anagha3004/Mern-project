const express = require("express");
const Router = express.Router();

const {registerUser,UserLogin,currentUser} = require("../controllers/UserController.js");

const validateToken = require("../middleware/ValidationToken.js");

Router.route("/register").post(registerUser)

Router.route("/login").post(UserLogin)
Router.route("/u/current").get(validateToken, currentUser);

module.exports = Router;


// const express = require("express");
// const router = express.Router();  // Use the correct variable for routing

// const { registerUser, UserLogin, currentUser } = require("../controllers/UserController.js");
// const contactRouter = require("./ContactRoutes"); // If you want to use ContactRoutes, rename it for clarity
// const validateToken = require("../middleware/ValidationToken.js");

// // Define routes for the User Routes
// router.route("/register").post(registerUser);
// router.route("/login").post(UserLogin);
// router.route("/u/current").get(validateToken, currentUser);

// // If you intend to use ContactRoutes, you can add the contact routes here
 

// module.exports = router;
