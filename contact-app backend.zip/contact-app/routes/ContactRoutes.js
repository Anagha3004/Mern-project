const express = require('express');

const router = express.Router();
const {getcontact,deletecontact ,created,getcontc,updatecontact} = require("../controllers/ContactController");
const validateToken = require('../middleware/ValidationToken');

router.use(validateToken)
router.route("/").get(getcontact).post(created);;




router.route('/:id').put(updatecontact).delete(deletecontact).get(getcontc );



module.exports = router;

