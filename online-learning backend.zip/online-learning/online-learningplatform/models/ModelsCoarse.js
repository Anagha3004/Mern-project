const mongoose = require("mongoose");

const coarseSchema = mongoose.Schema({
    user_id:{
        type: mongoose.Schema.Types.ObjectId,
        required:true,
        ref:"user"
    },
    coarsename:{
        type:String,
        required:true
    },
    tutor:{
        type:String,
        required:true
    },
    price:{
        type:Number,
        required:true
    },
    duration: {
        type: String,          // The duration of the course (e.g., "4 weeks", "10 hours")
        required: true,        // Makes this field mandatory
        trim: true
    }
}, {
    timestamps: true   
});

module.exports = mongoose.model("coarse", coarseSchema);