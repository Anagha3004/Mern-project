const express = require("express");
const Router = express.Router();
const {Register,Login,currentUser} = require("../Controller/TutorController");
const verifytoken = require("../middleware/validateToken");

Router.route("/register").post(Register)
Router.route("/login").post(Login)
Router.route("/current").get(verifytoken,currentUser)
module.exports = Router;