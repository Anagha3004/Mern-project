const express = require("express")

const router = express.Router();

const {getcoarse,createcoare,getcoarseById,updatecoarse,deleteCoarse} = require("../Controller/CoarseController");
const verifytoken = require("../middleware/validateToken");



router.use(verifytoken)
router.route('/').get(getcoarse).post(createcoare )
router.route('/:id').get(getcoarseById).put(updatecoarse).delete(deleteCoarse)

module.exports = router;