const mongoose = require("mongoose");

const DbConnection = async(req, res)=>{
    try{
        const connect = await mongoose.connect("mongodb+srv://anuanagha381:Faith@faith.3vaco.mongodb.net/faith?retryWrites=true&w=majority&appName=Faith");
        console.log("db connected successfully!")
    }catch(err){
        console.log(err)
    }
     
}   

module.exports = DbConnection;