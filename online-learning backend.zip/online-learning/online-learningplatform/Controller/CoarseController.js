const asynchandler = require("express-async-handler")
const coarse = require("../models/ModelsCoarse.js")



//  get all coarse


const getcoarse = asynchandler(async(req,res)=>{
    const coarseList = await coarse.find({user_id : req.user.id});
    res.status(200).json( coarseList)
})

// post a contact

const createcoare = asynchandler(async(req,res)=>{
    const {coarsename, tutor, price, duration} = req.body;
    console.log(req.body)
    if(!coarsename || !tutor || !price || !duration ){
        res.status(400);
        throw new Error("all fields are maditory")
    }
    const newcoarse = await coarse.create({
        coarsename, tutor, price, duration,user_id:req.user.id
    })
    res.status(200).json(newcoarse)
})

// get coarse by id

const getcoarseById = asynchandler(async(req,res)=>{
    const coarseById = await coarse.findById(req.params.id)
    if(!coarseById){
        res.status(404)
        throw new Error("not found")
    }
    res.status(200).json(coarseById)
})

// update coarse by id
const updatecoarse = asynchandler(async(req,res)=>{
    const update = await coarse.findById(req.params.id)
    if(!update){
        res.status(404);
        throw new Error("not found")
    }

        if(update.user_id.toString() !== req.user.id){
            res.status(403)
            throw new Error("user dont have permission")
        }


    const updated = await coarse.findByIdAndUpdate(
        req.params.id,
        req.body,
        {new : true}
    )
    res.status(200).json( updated)
})

// delete coarse by id
const deleteCoarse = asynchandler(async(req,res)=>{
   
    const coarseByIdDlt = await coarse.findById(req.params.id)
    if(!coarseByIdDlt){
        res.status(404)
        throw new Error("not found")
    }
    if(coarseByIdDlt.user_id.toString() !== req.user.id){
        res.status(403)
        throw new Error("user dont have permission")
    }

     
    await coarseByIdDlt.deleteOne({_id: req.params.id})

    res.status(200).json(coarseByIdDlt)
})



module.exports = {getcoarse,createcoare,getcoarseById,updatecoarse,deleteCoarse }