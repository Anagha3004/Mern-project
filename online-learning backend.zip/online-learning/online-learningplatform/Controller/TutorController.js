const TutorRegiter = require("../models/TutorModel");
const asynchandler = require("express-async-handler");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const express = require("express");
const validateToken = require("../middleware/validateToken")



const Register = asynchandler(async(req,res)=>{
    const {username , email, password} = req.body;
    if(!username || !email || !password){
        res.status(400)
        throw new Error("All fields are manditory")
    }
    const available = await TutorRegiter.findOne({email})
    if(available){
        res.status(400)
        throw new Error("user with this email already exists")
    }

    //  hasspassword

    const hasspassword = await bcrypt.hash(password, 10)

    const createUser = await TutorRegiter.create({
        username,
        email,
        password:hasspassword
    })
    console.log("createdUser" ,createUser)
    if(createUser){
        res.status(200).json({id:createUser.id, email: createUser.email})
        
    }else{
        res.status(400)
        throw new Error("Creating user failed")
    }
})




const Login = asynchandler(async(req,res)=>{
    const {email,password} = req.body;
    if(!email || !password){
        res.status(400)
        throw new Error("all fields are manditory")

    }

    const check = await TutorRegiter.findOne({email})
    if (!check) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    if(email && (await bcrypt.compare(password, check.password))){
        const jsonwebtkn = jwt.sign({
            check:{
                username: check.username,
                email: check.email,
                id: check.id
            }
        },process.env.token,
        {expiresIn: "30m"});
    res.status(200).json({jsonwebtkn})
    }else{
        res.status(400)
        throw new Error("invalid credentials")
    }
})

const currentUser = asynchandler(async(req,res)=>{
    res.status(200).json(req.user)
})


module.exports = {Register, Login ,currentUser}



