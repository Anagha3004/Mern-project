const asynchandler = require("express-async-handler");
const jwt = require("jsonwebtoken");


const verifytoken = asynchandler(async(req,res,next)=>{
    let token;
    const bearerToken = req.headers.Authorization || req.headers.authorization
    if(bearerToken && bearerToken.startsWith("Bearer")){
        token = bearerToken.split(" ")[1]
        jwt.verify(token, process.env.token, (err,decoded)=>{
            if(err){
                res.status(401)
                throw new Error("user not found or unauthorised used")
            }else{}

            req.user = decoded.check
            console.log(decoded)
            next();
        })
        if(!token){
            res.status(404)
            throw new Error("user is not authorised or no token")
    } 
}
})

module.exports = verifytoken;