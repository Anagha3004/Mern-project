
exports.constants = {
    Validation_error : 400,
    UnAuthorized_error :401,
    Forbidden_error :403,
    Not_found : 404,
    Server_error : 500
}