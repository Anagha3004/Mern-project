const { constants } = require("./constant");

const errorHandler = (err, req, res, next) => {
    const statusCode = res.statusCode ? res.statusCode : 500;

    switch(statusCode) {
        case constants.Validation_error:
            res.status(statusCode).json({ title: "Validation Error", message: err.message, stackTrace: err.stack });
            break;
        case constants.UnAuthorized_error:
            res.status(statusCode).json({ title: "UnAuthorized_error", message: err.message, stackTrace: err.stack });
            break;
        case constants.Forbidden_error:
            res.status(statusCode).json({ title: "Forbidden_error", message: err.message, stackTrace: err.stack });
            break;
        case constants.Not_found:
            res.status(statusCode).json({ title: "Not_found", message: err.message, stackTrace: err.stack });
            break;
        case constants.Server_error:
            res.status(statusCode).json({ title: "Server_Error", message: err.message, stackTrace: err.stack });
            break;
        default:
            console.log("Unhandled error:", err);
            res.status(500).json({ title: "Unknown Error", message: err.message });
            break;
    }

    next(); // Call next middleware, even if not strictly required
};

module.exports = errorHandler;
