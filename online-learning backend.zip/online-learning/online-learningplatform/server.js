const express = require("express");
const errorHandler = require("./middleware/ErrorHandler.js");
const DbConnection = require("./config/DbConnection.js");
const TutorModel = require("./models/TutorModel.js");
const dotenv = require("dotenv").config();
const app = express();
DbConnection();
TutorModel();
 

app.use(express.json());
app.use('/api/coarse', require("./Routes/CoarseRoutes.js"))
app.use("/api/tutor", require("./Routes/TutorRoutes.js"))
app.use(errorHandler)
 
port = 5000;
app.listen(port,()=>{
    console.log(`port is running on ${port}`)
})