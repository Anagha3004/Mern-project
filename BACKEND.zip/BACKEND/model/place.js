const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// const uniqueValidator = require('mongoose-unique-validator');

//creating schema and from schema we will create model
const placeSchema = new Schema({
    title : {type: String, required: true},
    description: {type: String, required: true},
    image: {type: String, required: true},
    address: {type: String, required: true},
    location: {
        lat: {type: Number, required: true},
        lng: {type: Number, required: true}
    },
    creator: {type:mongoose.Types.ObjectId,required:true,ref:'User'}
})

module.exports = mongoose.model('Place', placeSchema);

/* A Schema in Mongoose is a blueprint that defines how data is organized within
a mongodb collection. It specifies the fields.

Model is the compiled version of schema. it serves as a constructor that creates
and interacts documents in mongodb collection based on the defined schema
Models provide an interface for CRUD */



