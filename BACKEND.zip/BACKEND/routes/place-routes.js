const express = require('express');
const HttpError = require('../model/http-error');


//create a router object to handle routes or path
const router = express.Router();
//import placecontroller
const placeControllers = require('../controllers/place-controller');
const {check} = require('express-validator');
const fileUpload = require('../middleware/file-upload');
//get places by placeid
router.get('/:pid',placeControllers.getPlaceById);
//get places by creatorid
router.get('/user/:uid',placeControllers.getPlaceByCreator);

//create post

router.post('/',fileUpload.single('image'),[check('title').not().isEmpty(),
    check('description').isLength({min:5}),
    check('address').notEmpty()],placeControllers.createPlace);
    
//update or patch
router.patch('/:pid',placeControllers.updatePlace);
//delete
router.delete('/:pid',placeControllers.deletePlace);



module.exports = router

