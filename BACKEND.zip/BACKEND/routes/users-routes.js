const express = require('express');
const router = express.Router();
const userscontroller = require('../controllers/user-controllers');
const fileUpload = require('../middleware/file-upload')

router.get('/',userscontroller.getUsers);
router.post('/signup',fileUpload.single('image'),userscontroller.signup);
router.post('/login',userscontroller.login);

module.exports = router;