const express = require('express');
const {use} = require('../routes/place-routes');

const HttpError = require("../model/http-error");
// create a router object to handle route on path
const router = express.Router();
const {v4: uuidv4} = require('uuid');
const User = require('../model/user')
const bcrypt = require('bcryptjs')
// //create a router object to handle routes or path

// router.get('/',(req,res,next)=>{
//     console.log("GET Request in places")
//    res.json({message: 'It does not works!!!!'})
// })

// module.exports = router

// var DUMMY_USERS = [
//     {
//         id: 'u1',
//         name: 'Rashmi',
//         email: 'rashmi@gmail.com',
//         password: 'rash123'

//     }
    
// ]

/*TASK*/
//create API for get all users,signup for registration,login

//get all users
const  getUsers =async (req,res,next)=>{
    let users;
    try{
        users=await User.find({},'-password');//we dont need password
    }
    catch(err){
        const error=new HttpError('Fetching users up failed,please try again',500)
        return next(error);
    }
    res.json({users:users.map(user=>user.toObject({getters:true}))})
}

//signup
const signup = async(req,res,next)=>{
    const {name,email,password} = req.body;
    //checking this is an existing user

    let existingUser
    try{
        existingUser = await User.findOne({email:email});

    }catch(err){
        const error = new HttpError('Signing up failed,please try again',500);
        return next(error)
    }
    if (existingUser){
        const error=new HttpError('User with email already exist!!!!!! plz login...',422);
        return next(error);
    }
    //hashing the password
    let hashedPassword;
    try{
        //12: salt rounds or cost factor: it determines how 
        //computationally intensive the hashing process will be
        hashedPassword = await bcrypt.hash(password,12);
    }catch(err){
        const error = new HttpError
        ('could not create user! Please try again', 500);
        return next(error);
    }
    //normalize the path separator
    const imagePath = req.file.path.replace(/\\/g,'/');
    const createdUser = new User({
        //id: uuidv4(),
        name:name,
        email:email,
        password:hashedPassword,
        image: 'http://localhost:5000/'+ imagePath,
        places:[],
    })
    try{
        await createdUser.save();

    }catch(err){
        console.log(err)
        const error = new HttpError
        ('Signing up failed',500);
        return next(error);
    }
    
    // DUMMY_USERS.push(createdUser);
    res.status(201).json({user: createdUser.toObject({getters:true})});
}

//login
const login = async(req, res, next) => {
    const { email, password } = req.body;
    let existingUser;
    try {
        existingUser = await User.findOne({ email: email });
    } catch (err) {
        const error = new HttpError('Logging up is  failed, please try again later', 500);
        return next(error);
    }
    if (!existingUser) {
        const error = new HttpError('Invalid credentials', 401);
        return next(error);
    }
    // create a boolean variable
    let isValidPassword = false;
    try{
        isValidPassword = await bcrypt.compare(password, existingUser.password);
    }catch(err){
        const error = new HttpError('could not log in, please check your credentials', 500);
        return next(error);
    }
    if(!isValidPassword){
        const error = new HttpError('Invalid credentials, could not log in', 401);
        return next(error);
    }
    res.status(200).json({ message: 'logged in' ,
    user: existingUser.toObject({getters:true})
    });
}


exports.getUsers = getUsers;
exports.signup = signup;
exports.login = login;

