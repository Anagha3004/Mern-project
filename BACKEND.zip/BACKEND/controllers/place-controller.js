const express = require('express');
const HttpError = require('../model/http-error');
const {v4 : uuidv4} = require('uuid');
const {validationResult} = require('express-validator');
const { default: mongoose } = require('mongoose');
const Place = require('../model/place');
const User = require('../model/user')

//creating a dummy record to learn 
// POST PUT  PATCH DELETE GET methods
// var DUMMY_PLACES = [
//     {
//         id: 'p1',
//         title: 'Empire State Building',
//         description: 'One of the most famous sky scappers in the world',
//         location: {
//             lat: 40.85259,
//             lng: -74.25852
//         },
//         address: '20W EAST New York',
//         creator: 'u1'
//     }
// ]
//get places by placeid 
const getPlaceById = async (req,res,next)=>{
    console.log("GET Request in places")
    const placeId = req.params.pid;
    // const place = DUMMY_PLACES.find(p=>{
    //     return p.id === placeId;
    // })


let place;
try{
    place = await Place.findById(placeId);
}
catch(err){
    const error = new HttpError;
    ('Something went wrong,could not find a place', 500);
    return next(error);

}
//if place is empty
if(!place){
    // return res.status(404).json(
    //     {message: 'could not find a place with the given pid'} )
    // const error = new Error('could not find a place with given pid');
    // error.code = 404;
    // throw error; //go to app.js and error handler middleware
    throw new HttpError('could not find a place with given pid', 404)
}
    res.json({place:place.toObject({getters:true})})
}


//TASK: create a router to get place by creatorId
const getPlaceByCreator = async(req,res,next)=>{
    console.log("GET Request in places")
    const userId = req.params.uid;
    //     const place = DUMMY_PLACES.find(p=>{
    //     return p.creator === userId;
    // })
let place;
try{
        place = await Place.find({creator:userId});
}
catch(err){
    const error = new HttpError('something went wrong ,could not find a place',500);
    return next(error);
}
//if place is empty
if(!place || place.length === 0){
    // return res.status(404).json(
    //     {message: 'could not find a place with the given pid'})
    // const error = new Error('could not find a place with given pid');
    // error.code = 404;
    // throw error; //go to app.js and error handler middleware

    return next(new HttpError('could not find a place with given creatorid', 404));
}
    res.json({place:place.map(place=>place.toObject({getters:true}))})
}

// const getPlaceByCreator =('/',(req,res,next)=>{
//     console.log("GET Request in places")
//     res.json({message: 'It works!!!!'})
// })

//post method
const createPlace = async(req,res,next)=>{
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        console.log(errors);
        throw new HttpError('Invalid inputs passed check your data',422)
    }
    const {title, description, address, creator} = req.body;
//     const createPlace = {
//         id: uuidv4(),
//         title: title,
//         description: description,
//         location: location,
//         address: address,
//         creator: creator
//     }
//     DUMMY_PLACES.push(createPlace);
//     res.status(201).json({place:createPlace});
// }
    const imagePath = req.file.path.replace(/\\/g,'/');
    const createPlace = new Place({
        title: title,
        description: description,
        location: {
            lat: 85.2699,
            lng:5.26599
        },
        address: address,
        image: 'http://localhost:5000/' + imagePath,
        creator: creator

    })
    let user;
    try {
        user = await User.findById(creator);
    }catch(err){
        const error = new HttpError('creating place failed!, Please try again', 500);
        return next(error);
    }
    if(!user){
        const error = new HttpError('could not find a user with id,Please try again',404);
        return next(error)
    }
    try{
        const sess = await mongoose.startSession();
        sess.startTransaction();
        await createPlace.save({session:sess});
        user.places.push(createPlace);
        await user.save({session:sess})
        await sess.commitTransaction()
    }catch(err){
        const error = new HttpError
        ('adding place failed',500);
        return next(error)
    }
    
    res.status(201).json({place:createPlace});
}

//update
const updatePlace = async(req,res,next)=>{
    // i am gone to update two fields
    const {title,description} = req.body;
    const placeId = req.params.pid;
    // const updatePlace = {...DUMMY_PLACES.find(p=>p.id === placeId)}
    // const placeindex = DUMMY_PLACES.findIndex(p=>p.id === placeId);
    
    //fetching the place by id
    let place;
    try{
        place = await Place.findById(placeId);
    }catch(err){
        const error = new HttpError('updating place failed!',500);
        return next(error);

    }
    //update the title and description
    place.title = title;
    place.description = description;
    try{
        await place.save();
    }catch(err){
        const error = new HttpError('something went wrong on update!', 500);
        return next(error);
    }
    res.status(200).json({place: place.toObject({getters: true})});
    
    
    // DUMMY_PLACES[placeindex] = updatePlace;
    // res.status(200).json({place:updatePlace})
}

//delete
const deletePlace = async(req,res,next)=>{
    const placeId = req.params.pid;
    // DUMMY_PLACES = DUMMY_PLACES.filter(p=>p.id!==placeId);
    // res.status(200).json({message: 'Deleted Place.....'})
    let place;
    try{
        place = await Place.findById(placeId);
    }catch(err){
        const error = new HttpError('Deletion failed!',500);
        return next(error);

    }
    try{
        await place.deleteOne();
    }catch(err){
        const error = new HttpError('something went wrong, could not delete place!', 500);
        return next(error);
    }
    res.status(200).json({message: 'Deleted Place...'});
}

exports.createPlace = createPlace
exports.getPlaceById = getPlaceById
exports.getPlaceByCreator = getPlaceByCreator
exports.updatePlace = updatePlace
exports.deletePlace = deletePlace