//starting point of our application
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const placeroutes = require('./routes/place-routes');
const {error} = require('console');
const HttpError = require('./model/http-error');
const usersroutes = require('./routes/users-routes');
const  mongoose  = require('mongoose');
const path = require('path')
const fs = require('fs');


//to fetch the data from the body:
app.use(bodyParser.json());
app.use('/uploads/images', express.static(path.join('uploads','images')))

//to handle cors policy error

app.use((req,res,next)=>{
   res.setHeader('Access-Control-Allow-Origin', '*');
   res.setHeader('Access-Control-Allow-Headers',
       'Origin, X-Requested-With, Content-type, Accept, Authorization');
       res.setHeader(
         "Access-Control-Allow-Methods",
         "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS"
       );
   next();
})

app.use('/api/places',placeroutes);
app.use('/api/users',usersroutes);

//error handling middleware
/* this is a middleware function express applies on every incoming request 
if a function is passed with four parameters,express will treat this as
special function or error handling function.
This function will only be executed if the request ius having error attached to it  */

//middleware to handle unimplemented routes or path

app.use((req,res,next)=>{
    const error = new HttpError('could not find this routes',404);
    throw error;
});

app.use((err,req,res,next)=>{
    //this condition will delete the image when the error occurs
    if(req.file){
        fs.unlink(req.file.path,(err)=>{//deletes the file
            console.log(err);
        });
    }
    if(res.headerSent){
        return next(err)
    }
    res.status(err.code || 500);
    res.json({message: err.message} || 'An unknown error occured!');
})
mongoose.connect('mongodb+srv://rashreji15:Faith@faith.ykpqv.mongodb.net/faith?retryWrites=true&w=majority&appName=faith')
.then(()=>{

//to start the server
app.listen(5000);
}).catch(err=>{
console.log(err);
})


